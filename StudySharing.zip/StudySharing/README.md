# 📷 StudySharing
- 한림대학교 캡스톤디자인
<br>
<br>

## 📷 스크린샷
![1](https://user-images.githubusercontent.com/87289223/234354672-8fbb669c-f01c-450f-aae7-f8c9a8bf4711.PNG)
![2](https://user-images.githubusercontent.com/87289223/234354680-bb541f75-7a32-4276-b2ba-94a29d137129.PNG)

<br>
<br>

## 📝 팀원
- 팀장: 20172926 경영학과 (스마트IOT) 이진석
- 팀원: 20172913 경영학과 (스마트IOT) 최승현
<br>
<br>

## 📝 프로젝트 소개
- 복수전공생으로써 코딩을 처음에 공부할 때, 어려움을 많이 겪었어서 서로의 코드를 공유하면 좋겠다는 생각으로 시작!
- 티어 (등급) 제도를 도입해서 좋아요 수에 따라서 등급이 올라서 성취감을 느껴보자!
- 성공한 SNS모델인 인스타그램을 기반으로 기능 및 페이지를 조금씩 추가할 예정!
<br>
<br>

## 📝 사용 기술
- Kotlin
- Firebase
- ViewModel / LiveData
- Retrofit2
<br>
<br>
